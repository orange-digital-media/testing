<?php include 'header.php';?>
<section class="rrSlideDetails">
	<div class="container">
		<div class="row">
			<div class="col-md-6 col-12">
							<div class="card cardFormRegisterDett">
					<div class="card-body">

					    <h1 class="card-title"> Meridian Park</h1>
						<h2 class="card-title">At Sarjapur Road, Bangalore</h1>
						<h3 class="card-title">By Prestige Group</h3>
						
                          
						<h4 class="card-title">Total Development- 180 Acres</h4>
					    <!-- <h4 class="card-title">Possession - Dec 2024</h4> -->
						<h4 class="card-title">Number of Units - 930</h4>
						<h4 class="card-title">Possession - 2025 Onwards</h4>
						

						<button type="submit" class="btn btnBtwRegg">Limited Period Prices</button>

						<h3 class="card-title">3 BHK Apartment Starts</h3>
						<h1 class="card-title">₹ 95 Lacs*</h1>
                         
						</form>

						
                          <button type="submit" class="btn btnBtwReg">Enquire Now</button>
						</form>
						<h6 class="rerNo">RERA No - On Request</h6>

					</div>
				</div>
			</div>
			<div class="col-md-6 col-12">
				<div class="card cardFormRegisterDet1">
					<div class="card-body">
						<h1 class="card-title">BOOK A SITE VISIT</h1>
						<form method="post" action="<?=base_url('sendMail')?>">
							<div class="form-group">
								<input type="text" name="name" placeholder="Name" required="">
							</div>
							<div class="form-group">
								<input type="text" id="mobile" class="phone-field mobile" name="mobile" placeholder="10 Digits Mobile Number" required="" pattern="[1-9]{1}[0-9]{9}">
							</div>
							<div class="radioLeft1">
								<b>Whatsapp Number</b><br>
								<input name="whatsapp_option" id="whatsapp_option" class="whatsapp_option" value="same_as_above" type="radio" required="" checked=""><label>&nbsp;Same as Above&nbsp;&nbsp;&nbsp;</label>  
								<input name="whatsapp_option" id="whatsapp_option" class="whatsapp_option" value="different_number" type="radio"><label>&nbsp;Different Number</label> <br>
							</div>
							<div class="form-group" id="whatsapp_mobile_div" class="whatsapp_mobile_div" style="display: none" >
								<input type="text" id="whatsapp_mobile" class="phone-field whatsapp_mobile" name="whatsapp_mobile" placeholder="10 Digits Whatsapp Number" >
							</div>

							<div class="form-group">
								<input type="text" name="current_city" placeholder="Enter Your City" required="">
							</div>
							<div class="form-group">
								<input type="email" name="email" placeholder="Email" required="">
							</div>
							<div style="display:none;">
								<input type="text" value="" class="utm_source" name="utm_source" />
								<input type="text" value="" class="utm_medium" name="utm_medium" />
								<input type="text" value="" class="utm_term" name="utm_term" />
								<input type="text" value="" class="utm_campaign" name="utm_campaign" />
								<input type="text" value="" class="utm_content" name="utm_content" />

								<input type="text" value="" class="utm_site" name="utm_site" />
								<input type="text" value="" class="utm_url" name="utm_url" />
								<input type="text" value="" class="utm_title" name="utm_title" />
								<input type="text" value="" class="utm_timestamp" name="utm_timestamp" />
								<input type="text" value="" class="utm_itemID" name="utm_itemID" />
							</div>
							<button type="submit" class="btn btnBtwReg1">Enquire Now</button>
						</form>
						<h3 class="">Call Us 24/7 @ +91 8197967475</h3>

					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="royaloverview anchor mt-3" id="royaloverview">
	<div class="container">
		<h1>OVERVIEW</h1>
		<div class="row">
			<div class="col-md-6">
				<h1 class="rajGreenDescript">The Prestige City - Meridian Park</h1>
				<h6 class="text-center rajGreenDescript">RERA No : On Going <h6>
				<p class="royal">Prestige Meridian Park is a tower of apartments that form The Prestige City, a planned residential development developed through Prestige Group. Prestige Group in the idyllic site of Ittangur is located on Sarjapur road. It is located in the most sought-after and soon-to-be developed real estate area in South-East Bangalore, and The Prestige City is a sprawling township with an area of 180 acres. Meridian Park</p>
				<p class="royal">
They include a luxurious and exclusive clubhouse and many places to foster social interaction between residents, such as lawns for events, which are ideal for hosting parties, events and events. Children’s play areas, senior citizen’s area, pools for adults and youngsters, fitness zones and a modern gym will provide an endless amount of entertainment, fitness, leisure, and fun</p>
				</p>
				<div class="text-center">
				<button type="subit" class="btn btnRequest" data-toggle="modal" data-target="#uploadModal">Download Brochure</button>
			    </div>
				</div>
				<div class="col-md-6">

					<img src="<?=base_url('images/kush.jpg')?>">
				</div>
			</div>
		</div>
	</section>









	<section class="Amenities  anchor mt-3" id="Amenities">
		<div class="container">
			<h1 class="text-center pt-3 mb-4">Amenities</h1>
			<div class="row justify-content-center pl-md-4">
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/swimming.png')?>">
					<h4>Swimming Pool</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/prabha.png')?>">
					<h4>Mini Theatre</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/Business.png')?>">
					<h4>Club House</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/gym.png')?>">
					<h4 class="gymDet">Gym</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/meditation-yoga.png')?>">
					<h4>Yoga Area</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/skating.png')?>">
					<h4>Skating</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/play.png')?>">
					<h4>Basketball Court</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/badminton.png')?>">
					<h4>Badminton</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/gate.png')?>">
					<h4>Futsal Court</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/lawn.png')?>">
					<h4>Multipurpose Lawn</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/table-tennis.png')?>">
					<h4>Tennis Court</h4>
				</div>
				<div class="col-md-2 col-6 imgAmmmedites">
					<img src="<?=base_url('images/snooker.png')?>">
					<h4>Party Lawn</h4>
				</div>
			</div>
		</div>
	</div>
</section>


<section class="anchor" id="price">
	<div class="container">
		<h1 class="text-center pricehe pt-3 mb-4">Pricing</h1>
		<div class="row">
			

			

			<div class="col-md-3 m-auto">
				<div class="card cardBhkApartment mt-3">
					<div class="card-body">
						<h1> 3 BHK</h1>
					</div>
				</div>

				<div class="card cardUnitArea">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Area: 1387 sq.ft.</p>
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 95 Lacs Onwards*</p>
						<div class="nowButtonDet">
							<button type="submit" class="btn priceDetButton" data-toggle="modal" data-target="#uploadModal">Price</button>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-3 m-auto">
			    
				<div class="card cardBhkApartment mt-3">
					<div class="card-body">
						<h1>3 BHK</h1>
					</div>
				</div>

				<div class="card cardUnitArea">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Area: 1665 sq.ft.</p>
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 1.10 Cr Onwards*</p>
						<div class="nowButtonDet">
							<button type="submit" class="btn priceDetButton" data-toggle="modal" data-target="#uploadModal">Price</button>
						</div>
					</div>
				</div>
			</div>

			<div class="col-md-3 m-auto">
				<div class="card cardBhkApartment mt-3">
					<div class="card-body">
						<h1>3 BHK</h1>
					</div>
				</div>

				<div class="card cardUnitArea">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Area: 1865 sq.ft</p>
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i>  1.22 Cr Onwards*</p>
						<div class="nowButtonDet">
							<button type="submit" class="btn priceDetButton" data-toggle="modal" data-target="#uploadModal">Price</button>
						</div>
					</div>
				</div>
			</div>
			
			<!-- <div class="col-md-3">
				<div class="card cardBhkApartment mt-3">
					<div class="card-body">
						<h1>4 BHK</h1>
					</div>
				</div>

				<div class="card cardUnitArea">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Area: 2204 - 2290 sq.ft</p>
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i>  1.34 - 1.39 Cr Onwards*</p>
						<div class="nowButtonDet">
							<button type="submit" class="btn priceDetButton" data-toggle="modal" data-target="#uploadModal">Price</button>
						</div>
					</div>
				</div>
			</div>
 -->


			<!-- <div class="col-md-4">
				<div class="card cardBhkApartment mt-3">
					<div class="card-body">
						<h1>15 x 18 M PLOT</h1>
					</div>
				</div>

				<div class="card cardUnitArea">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Area: 2906 sq.ft</p>
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i>  1.60 Cr Onwards*</p>
						<div class="nowButtonDet">
							<button type="submit" class="btn priceDetButton" data-toggle="modal" data-target="#uploadModal">Price</button>
						</div>
					</div>
				</div>
			</div> -->

			<!-- <div class="col-md-4">
				<div class="card cardBhkApartment mt-3">
					<div class="card-body">
						<h1>15 x 24 M PLOT</h1>
					</div>
				</div>

				<div class="card cardUnitArea">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Area: 3875 sq.ft</p>
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i>  2.13 Cr Onwards*</p>
						<div class="nowButtonDet">
							<button type="submit" class="btn priceDetButton" data-toggle="modal" data-target="#uploadModal">Price</button>
						</div>
					</div>
				</div>
			</div>
			<div class="col-md-4">
				<div class="card cardBhkApartment mt-3">
					<div class="card-body">
						<h1>ODD SIZES PLOT</h1>
					</div>
				</div> -->
<!-- 
				<div class="card cardUnitArea">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> 235 PLOTS</p>
						<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i>Enquire Now</p>
						<div class="nowButtonDet">
							<button type="submit" class="btn priceDetButton" data-toggle="modal" data-target="#uploadModal">Price</button>
						</div>
					</div>
				</div>
			</div>

 -->

		</div>
	</section>

<section class="specificationDet mt-4" id="Specification">
	<h1 class="text-center mb-4 text-white">Project Highlights</h1>
	<div class="container">
		<div class="row">
			<div class="col-md-6">
				<div class="card">
					<div class="card-body">
				<ul class="text-black">
					<li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Almost all the units are oriented towards the east & west.</li>
					<li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>It has a grand entrance with a 65 feet wide road.
					</li>
				</ul>
			</div>
			</div>
			</div>
			<div class="col-md-6">
					<div class="card">
					<div class="card-body">
				<ul>
				    <li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Internals roads of acomfortable wide of 40 feet and 30 feet.</li>
					<li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Three Main entrances on the all sides of the property make accessing the site</li>
				</ul>
			</div>
		</div>
			</div>
	<!-- 		<div class="col-md-4">
				<ul>
					<li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Indoor Games Room</li>
					<li><i class="fa fa-dot-circle-o" aria-hidden="true"></i>Dance & Zumba Studio</li>
				</ul>
			</div> -->
		</div>
		<div class="requestCallBack mt-4">
			<button type="subit" class="btn btnRequest" data-toggle="modal" data-target="#uploadModal">Download Brochure</button>
		</div>
	</div>
</section>







<h1 class="text-center pricehe pt-3 mb-4">Walkthrough Video</h1>
<div class="container">
	<div class="row">
		<div class="col-md-12 m-auto">
			<!-- <div class="card"> -->
					<img width="100%" height="100%" data-toggle="modal" data-target="#uploadModal" src="<?= base_url('images/youtubeimg_1.jpg')?>">
			
				<!-- <iframe width="100%" height="800" class="youtubevideo_1" src="" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe> -->
			<!-- 	<div class="card-body">
				</div> -->
		</div>
	</div>
</div>
</div>
</section>
<section class="mt-4 map_section">
<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3889.478557716077!2d77.7629899141343!3d12.876920120434487!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae6f78c3e75109%3A0x65c327b0d8584026!2sThe%20Prestige%20City!5e0!3m2!1sen!2sin!4v1644304477385!5m2!1sen!2sin" width="100%" height="315" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
</section>








<?php include 'footer.php';?>