<?php include 'header.php';?>
<!-- <section class="pricingDetails mt-2" id="price">
	<h1 class="priceBannerDet">Pricing Details</h1>
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-md-3 col-lg-3">
				<div class="card cardBhkApartment mt-2">
					<div class="card-body">
					<h1>30'x30'</h1>
				    </div>
				</div>
				<div class="card cardUnitArea mb-4">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
					<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Plot Area: 900 Sqft</p>
					<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Price: ₹38 Lacs</p>
				    </div>
				</div>
			</div>
			<div class="col-md-3 col-lg-3">
				<div class="card cardBhkApartment mt-2">
					<div class="card-body">
					<h1>30'x40'</h1>
				    </div>
				</div>
				<div class="card cardUnitArea mb-4">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
					<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Plot Area: 1200 Sq Ft</p>
					<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Price: ₹48 Lacs</p>
				    </div>
				</div>
			</div>
			<div class="col-md-3 col-lg-3">
				<div class="card cardBhkApartment mt-2">
					<div class="card-body">
					<h1>30'x50'</h1>
				    </div>
				</div>
				<div class="card cardUnitArea mb-4">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
					<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Plot Area:1500 Sq Ft</p>
					<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Price: ₹58 Lacs</p>
				    </div>
				</div>
			</div>
			<div class="col-md-3 col-lg-3">
				<div class="card cardBhkApartment mt-2">
					<div class="card-body">
					<h1>30'x60'</h1>
				    </div>
				</div>
				<div class="card cardUnitArea mb-4">
					<img class="card-img-top" src="<?=base_url('images/home.png')?>">
					<div class="card-body">
					<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Plot Area:1800 Sq Ft</p>
					<p class="text-center"><i class="fa fa-check" aria-hidden="true"></i> Price: ₹68 Lacs</p>
				    </div>
				</div>
			</div>
		</div>
	</div>
</section> -->
<section class="thankuDetails">
<div class="container">
	<div class="row">
		<div class="col-md-12 col-lg-12 col-12">
	<div class="card cardThankuDet">
		<div class="card-body">
		<h1 class="text-center">Thank you for your Enquiry</h1>
		<p class="text-center">Our customer relationship manager will get in touch with you shortly</p>
	</div>
</div>
</div>
</section>

<?php include 'thankyoufooter.php';?>